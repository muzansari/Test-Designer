// server.js (ESM compatible)
import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs/promises';
import dotenv from 'dotenv';
import fetch from 'node-fetch';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = 3000;

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

const AWS_ACCESS_KEY_ID = process.env.AWS_ACCESS_KEY_ID;
const AWS_SECRET_ACCESS_KEY = process.env.AWS_SECRET_ACCESS_KEY;
const AWS_REGION = process.env.AWS_REGION || 'us-east-1';
const OPENAI_MODEL_ID = 'gpt-4o-mini';

if (!AWS_ACCESS_KEY_ID || !AWS_SECRET_ACCESS_KEY) {
  console.error('AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY must be set in your .env file.');
  process.exit(1);
}

// --- Multer for file uploads ---
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// --- Serve Static Frontend Files ---
app.use(express.static(path.join(__dirname, 'public')));

// --- API Endpoint: Code Analysis ---
app.post('/analyze', upload.array('codeFiles'), async (req, res) => {
  if (!req.files || req.files.length === 0) {
    return res.status(400).json({ error: 'No files uploaded.' });
  }

  const allVulnerabilities = [];

  for (const file of req.files) {
    const fileContent = file.buffer.toString('utf8');
    const fileName = file.originalname;
    console.log(`Analyzing file: ${fileName}`);

    try {
      const prompt = `
You are a security code analyzer. Analyze the following code for potential vulnerabilities.
Focus on common security issues like SQL injection, XSS, insecure direct object references,
insecure deserialization, broken authentication, sensitive data exposure, etc.
For each vulnerability found, provide:
1. A concise title.
2. The severity (Critical, High, Medium, Low).
3. A brief description of the vulnerability.
4. The exact code segment where the vulnerability is located.
5. Recommendations to fix it.
6. A clean code suggestion or an example of how the fixed code should look.
If no vulnerabilities are found, state "No vulnerabilities found."
Output the results in a structured JSON format, where each vulnerability is an object in a "vulnerabilities" array.
If no vulnerabilities are found, return an empty "vulnerabilities" array.
Now, analyze the following code from file "${fileName}":
\`\`\`${fileName.split('.').pop()}
${fileContent}
\`\`\`
`;

      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${OPENAI_API_KEY}`
        },
        body: JSON.stringify({
          model: OPENAI_MODEL_ID,
          messages: [
            { role: "system", content: "You are a security code analyzer." },
            { role: "user", content: prompt }
          ],
          temperature: 0.1
        })
      });

      const data = await response.json();
      const rawOutput = data.choices[0].message.content;

      let fileVulnerabilities = [];

      try {
        const cleanedOutput = rawOutput.replace(/```json|```/g, '').trim();
        const parsedResponse = JSON.parse(cleanedOutput);

        if (parsedResponse.vulnerabilities && Array.isArray(parsedResponse.vulnerabilities)) {
          fileVulnerabilities = parsedResponse.vulnerabilities.map(v => ({ ...v, file: fileName }));
        } else if (rawOutput.includes("No vulnerabilities found.")) {
          console.log(`No vulnerabilities reported for ${fileName}`);
        }
      } catch (parseError) {
        console.warn(`Could not parse output for ${fileName} as JSON. Raw output:`, rawOutput, parseError);
        if (rawOutput.includes("No vulnerabilities found.")) {
          console.log(`No vulnerabilities reported for ${fileName}`);
        } else {
          const heuristicVuln = parseHeuristic(rawOutput, fileName);
          if (heuristicVuln) {
            fileVulnerabilities.push(heuristicVuln);
          } else {
            console.warn(`No structured vulnerabilities extracted from ${fileName} after JSON parse failure.`);
          }
        }
      }

      allVulnerabilities.push(...fileVulnerabilities);
    } catch (error) {
      console.error(`Error processing file ${fileName}:`, error);
    }
  }

  res.json({ vulnerabilities: allVulnerabilities });
});

// --- Start Server ---
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

// --- Optional: Heuristic Parser Stub ---
function parseHeuristic(text, fileName) {
  if (text.includes("SQL Injection")) {
    return {
      title: "SQL Injection Vulnerability",
      severity: "High",
      description: "Detected possible SQL injection pattern.",
      file: fileName,
      codeSegment: "Unknown",
      recommendations: "Use parameterized queries.",
      cleanCodeSuggestion: "Use ORM or prepared statements.",
    };
  }
  return null;
}
