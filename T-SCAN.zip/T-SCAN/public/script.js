document.addEventListener('DOMContentLoaded', () => {
    const dropArea = document.getElementById('drop-area');
    const fileElem = document.getElementById('fileElem');
    const fileListContainer = document.getElementById('file-list');
    const analyzeButton = document.getElementById('analyze-button');
    const vulnerabilitiesOutput = document.getElementById('vulnerabilities-output');
    const themeToggle = document.getElementById('themeToggle');
    const exportButton = document.getElementById('export-button');

    // Summary counts
    const criticalCount = document.getElementById('critical-count');
    const highCount = document.getElementById('high-count');
    const mediumCount = document.getElementById('medium-count');
    const lowCount = document.getElementById('low-count');

    let uploadedFiles = []; // Stores File objects

    // --- Theme Toggling ---
    const currentTheme = localStorage.getItem('theme') ? localStorage.getItem('theme') : 'light';
    document.documentElement.setAttribute('data-theme', currentTheme);
    themeToggle.textContent = currentTheme === 'dark' ? 'Switch to Light' : 'Switch to Dark';

    themeToggle.addEventListener('click', () => {
        let theme = document.documentElement.getAttribute('data-theme');
        if (theme === 'dark') {
            document.documentElement.setAttribute('data-theme', 'light');
            localStorage.setItem('theme', 'light');
            themeToggle.textContent = 'Switch to Dark';
        } else {
            document.documentElement.setAttribute('data-theme', 'dark');
            localStorage.setItem('theme', 'dark');
            themeToggle.textContent = 'Switch to Light';
        }
    });

    // --- File Upload Logic ---
    ;['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ;['dragenter', 'dragover'].forEach(eventName => {
        dropArea.addEventListener(eventName, highlight, false);
    });

    ;['dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, unhighlight, false);
    });

    function highlight() {
        dropArea.classList.add('highlight');
    }

    function unhighlight() {
        dropArea.classList.remove('highlight');
    }

    dropArea.addEventListener('drop', handleDrop, false);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        handleFiles(files);
    }

    fileElem.addEventListener('change', (e) => {
        handleFiles(e.target.files);
    });

    function handleFiles(files) {
        for (const file of files) {
            // Prevent duplicate file names, though content might differ
            if (!uploadedFiles.some(f => f.name === file.name)) {
                uploadedFiles.push(file);
            }
        }
        renderFileList();
    }

    function renderFileList() {
        fileListContainer.innerHTML = ''; // Clear previous list
        if (uploadedFiles.length === 0) {
            fileListContainer.innerHTML = '<p style="color: #777; font-style: italic;">No files selected.</p>';
            return;
        }
        uploadedFiles.forEach((file, index) => {
            const fileItem = document.createElement('p');
            fileItem.textContent = file.name;

            const removeButton = document.createElement('button');
            removeButton.textContent = 'X';
            removeButton.classList.add('remove-file');
            removeButton.addEventListener('click', () => {
                uploadedFiles.splice(index, 1); // Remove file by index
                renderFileList(); // Re-render the list
            });
            fileItem.appendChild(removeButton);
            fileListContainer.appendChild(fileItem);
        });
    }

    // Initial render of file list (empty)
    renderFileList();

    // --- Analysis Button Click ---
    analyzeButton.addEventListener('click', async () => {
        if (uploadedFiles.length === 0) {
            alert('Please upload some code files first!');
            return;
        }

        vulnerabilitiesOutput.innerHTML = '<p class="placeholder">Analyzing code... Please wait.</p>';
        resetSummaryCounts();
        analyzeButton.disabled = true;
        analyzeButton.textContent = 'Analyzing...';

        const formData = new FormData();
        uploadedFiles.forEach(file => {
            formData.append('codeFiles', file); // 'codeFiles' is the expected field name on the backend
        });

        try {
            const response = await fetch('/analyze', { // Your backend API endpoint
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
            }

            const results = await response.json();
            displayAnalysisResults(results);

        } catch (error) {
            console.error('Error during code analysis:', error);
            vulnerabilitiesOutput.innerHTML = `<p class="placeholder" style="color: var(--critical-color);">Error: ${error.message}. Please try again.</p>`;
        } finally {
            analyzeButton.disabled = false;
            analyzeButton.textContent = 'Analyze Code';
        }
    });

    function resetSummaryCounts() {
        criticalCount.textContent = '0';
        highCount.textContent = '0';
        mediumCount.textContent = '0';
        lowCount.textContent = '0';
    }

    function displayAnalysisResults(results) {
        vulnerabilitiesOutput.innerHTML = ''; // Clear previous results

        if (results.vulnerabilities && results.vulnerabilities.length > 0) {
            let critical = 0, high = 0, medium = 0, low = 0;

            results.vulnerabilities.forEach(vuln => {
                const vulnItem = document.createElement('div');
                vulnItem.classList.add('vulnerability-item');

                const severityClass = vuln.severity.toLowerCase(); // 'critical', 'high', 'medium', 'low'

                vulnItem.innerHTML = `
                    <h4>${vuln.title} <span class="severity" style="background-color: var(--${severityClass}-color);">${vuln.severity}</span></h4>
                    <p><strong>File:</strong> ${vuln.file}</p>
                    <p><strong>Description:</strong> ${vuln.description}</p>
                    <pre class="code-segment">${vuln.codeSegment}</pre>
                    <p class="recommendations"><strong>Recommendations:</strong> ${vuln.recommendations}</p>
                    <p class="recommendations"><strong>Clean Code Suggestion:</strong> ${vuln.cleanCodeSuggestion}</p>
                `;
                vulnerabilitiesOutput.appendChild(vulnItem);

                // Update summary counts
                switch (severityClass) {
                    case 'critical': critical++; break;
                    case 'high': high++; break;
                    case 'medium': medium++; break;
                    case 'low': low++; break;
                }
            });

            criticalCount.textContent = critical;
            highCount.textContent = high;
            mediumCount.textContent = medium;
            lowCount.textContent = low;

            exportButton.style.display = 'inline-block'; // Show export button once results are available
        } else {
            vulnerabilitiesOutput.innerHTML = '<p class="placeholder">No vulnerabilities found. Great job!</p>';
            exportButton.style.display = 'none';
        }
    }

    // --- Export Button Click ---
    exportButton.addEventListener('click', async () => {
        // You'll need a backend endpoint to handle the actual export
        // For demonstration, let's assume it exports current results in a simple format
        alert('Export functionality is not yet implemented on the backend. Will export current displayed results.');

        // Example: If you want to send the *current* displayed results back to the server for export
        // let currentResults = [];
        // document.querySelectorAll('.vulnerability-item').forEach(item => {
        //     // Parse the displayed items back into a structure if needed
        //     // This is more complex. A simpler approach is for the backend to regenerate from its stored analysis.
        // });
        //
        // try {
        //     const response = await fetch('/export-results', {
        //         method: 'POST',
        //         headers: { 'Content-Type': 'application/json' },
        //         body: JSON.stringify({ format: 'PDF', results: currentResults }) // Or send a request to export the *last* analysis
        //     });
        //     if (response.ok) {
        //         const blob = await response.blob();
        //         const url = window.URL.createObjectURL(blob);
        //         const a = document.createElement('a');
        //         a.href = url;
        //         a.download = `SecurityAnalysisResults_${new Date().toISOString().slice(0,10)}.pdf`;
        //         document.body.appendChild(a);
        //         a.click();
        //         a.remove();
        //     } else {
        //         alert('Failed to export results.');
        //     }
        // } catch (error) {
        //     console.error('Export error:', error);
        //     alert('An error occurred during export.');
        // }
    });
});